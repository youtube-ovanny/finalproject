﻿Public Class Game
    ' Declare variables for gravity, pipe speed, and score
    Dim gravity As Integer = 5
    Dim pipespeed As Integer = 8
    Dim score As Integer = 0

    ' Timer tick event to handle game logic
    Private Sub gameTimer_Tick(sender As Object, e As EventArgs) Handles gameTimer.Tick
        ' Make the bird fall due to gravity
        flappyBird.Top += gravity

        ' Move the pipes to the left
        Pipebottom.Left -= pipespeed
        Pipetop.Left -= pipespeed

        ' Update the score
        scoreText.Text = "Score: " & score

        ' Reset pipe positions and increase score when they go off screen
        If Pipebottom.Left < -80 Then
            Pipebottom.Left = 800
            score += 1
        End If

        If Pipetop.Left < -80 Then
            Pipetop.Left = 800
            score += 1
        End If

        ' End game if bird collides with pipes or ground
        If flappyBird.Bounds.IntersectsWith(Pipebottom.Bounds) Or
           flappyBird.Bounds.IntersectsWith(Pipetop.Bounds) Or
           flappyBird.Bounds.IntersectsWith(ground.Bounds) Then

            gameTimer.Stop()
            scoreText.Text = "Game Over!"
        End If
    End Sub

    ' Event to handle bird jumping when a key is pressed
    Private Sub Game_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Space Then
            gravity = -5
        End If
    End Sub

    ' Event to reset gravity when the key is released
    Private Sub Game_KeyUp(sender As Object, e As KeyEventArgs) Handles MyBase.KeyUp
        If e.KeyCode = Keys.Space Then
            gravity = 5
        End If
    End Sub

    ' Initialize game when form loads
    Private Sub Game_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Start the game timer
        gameTimer.Interval = 20
        gameTimer.Start()
    End Sub
End Class
