﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Game
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Game))
        Pipebottom = New PictureBox()
        Pipetop = New PictureBox()
        flappyBird = New PictureBox()
        ground = New PictureBox()
        scoreText = New Label()
        gameTimer = New Timer(components)
        CType(Pipebottom, ComponentModel.ISupportInitialize).BeginInit()
        CType(Pipetop, ComponentModel.ISupportInitialize).BeginInit()
        CType(flappyBird, ComponentModel.ISupportInitialize).BeginInit()
        CType(ground, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Pipebottom
        ' 
        Pipebottom.Image = My.Resources.Resources.pipe
        Pipebottom.Location = New Point(362, 418)
        Pipebottom.Name = "Pipebottom"
        Pipebottom.Size = New Size(109, 286)
        Pipebottom.SizeMode = PictureBoxSizeMode.StretchImage
        Pipebottom.TabIndex = 0
        Pipebottom.TabStop = False
        ' 
        ' Pipetop
        ' 
        Pipetop.Image = CType(resources.GetObject("Pipetop.Image"), Image)
        Pipetop.Location = New Point(495, -59)
        Pipetop.Name = "Pipetop"
        Pipetop.Size = New Size(100, 266)
        Pipetop.SizeMode = PictureBoxSizeMode.StretchImage
        Pipetop.TabIndex = 1
        Pipetop.TabStop = False
        ' 
        ' flappyBird
        ' 
        flappyBird.Image = My.Resources.Resources.bird
        flappyBird.Location = New Point(69, 228)
        flappyBird.Name = "flappyBird"
        flappyBird.Size = New Size(82, 69)
        flappyBird.SizeMode = PictureBoxSizeMode.StretchImage
        flappyBird.TabIndex = 2
        flappyBird.TabStop = False
        ' 
        ' ground
        ' 
        ground.Image = CType(resources.GetObject("ground.Image"), Image)
        ground.Location = New Point(-16, 633)
        ground.Name = "ground"
        ground.Size = New Size(655, 126)
        ground.SizeMode = PictureBoxSizeMode.StretchImage
        ground.TabIndex = 3
        ground.TabStop = False
        ' 
        ' scoreText
        ' 
        scoreText.AutoSize = True
        scoreText.BackColor = Color.Moccasin
        scoreText.Font = New Font("Microsoft Sans Serif", 24.0F, FontStyle.Bold)
        scoreText.Location = New Point(266, 666)
        scoreText.Name = "scoreText"
        scoreText.Size = New Size(144, 37)
        scoreText.TabIndex = 4
        scoreText.Text = "Score: 0"
        ' 
        ' gameTimer
        ' 
        gameTimer.Enabled = True
        gameTimer.Interval = 20
        ' 
        ' Game
        ' 
        AutoScaleDimensions = New SizeF(7.0F, 15.0F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Aqua
        ClientSize = New Size(622, 707)
        Controls.Add(scoreText)
        Controls.Add(ground)
        Controls.Add(flappyBird)
        Controls.Add(Pipetop)
        Controls.Add(Pipebottom)
        Name = "Game"
        Text = "Game"
        CType(Pipebottom, ComponentModel.ISupportInitialize).EndInit()
        CType(Pipetop, ComponentModel.ISupportInitialize).EndInit()
        CType(flappyBird, ComponentModel.ISupportInitialize).EndInit()
        CType(ground, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Pipebottom As PictureBox
    Friend WithEvents Pipetop As PictureBox
    Friend WithEvents flappyBird As PictureBox
    Friend WithEvents ground As PictureBox
    Friend WithEvents scoreText As Label
    Friend WithEvents gameTimer As Timer
End Class
